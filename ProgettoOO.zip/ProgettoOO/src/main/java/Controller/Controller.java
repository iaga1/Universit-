package Controller;

import DAO.*;
import ImplementazionePostgresDAO.*;
import Model.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    private final List<Giocatore> listaGiocatori = new ArrayList<>();
    private final List<Amministratore> listaAmministratori = new ArrayList<>();
    private final List<Carriera> listaCarriere = new ArrayList<>();
    private final List<Squadra> listaSquadre = new ArrayList<>();

    public Controller(){
        getGiocatoriDatabase();
        getAmministratoriDatabase();
        getCarriereDatabase();
        getSquadreDatabase();
    }

    public List<Giocatore> getGiocatoriDatabase(){
       if(listaGiocatori.isEmpty()){
           GestionaleDAO gestionale = new ImplementazioneGestionaleDAO();

           ArrayList<String> listaNomi = new ArrayList<>();
           ArrayList<String> listaCognomi = new ArrayList<>();
           ArrayList<Date> listaDateNascita = new ArrayList<>();
           ArrayList<Date> listaDateRitiro = new ArrayList<>();
           ArrayList<String> listaPiedi = new ArrayList<>();
           ArrayList<String> listaRuoli = new ArrayList<>();
           ArrayList<String> listaFeature = new ArrayList<>();
           ArrayList<String> listaCf = new ArrayList<>();
           ArrayList<Carriera> listaCarriera = new ArrayList<>();

           List<Giocatore> giocatoriDB = gestionale.getGiocatori();

           for (Giocatore g : giocatoriDB){
               listaNomi.add(g.getNome());
               listaCognomi.add(g.getCognome());
               listaDateNascita.add(g.getDataNascita());
               listaDateRitiro.add(g.getDataRitiro());
               listaPiedi.add(g.getPiede());
               listaRuoli.add(g.getRuolo());
               listaFeature.add(g.getFeature());
               listaCf.add(g.getCf());
           }

           // Controllo di eventuali duplicati
           if (listaCf.size() != listaNomi.size() || listaNomi.size() != listaCognomi.size()) {
               // Qualcosa è andato storto, gestione errore
               return new ArrayList<>(); // Restituisce una lista vuota o fai altro
           }

           for (int i = 0; i < listaCf.size(); i++){
               Giocatore giocatore = new Giocatore(
                       listaNomi.get(i),
                       listaCognomi.get(i),
                       listaDateNascita.get(i),
                       listaDateRitiro.get(i),
                       listaPiedi.get(i),
                       listaRuoli.get(i),
                       listaFeature.get(i),
                       listaCf.get(i));
               listaGiocatori.add(giocatore);
           }
       }
        return listaGiocatori;
    }

    private void getAmministratoriDatabase(){
        GestionaleDAO gestionale = new ImplementazioneGestionaleDAO();

        ArrayList<String> listaLogin = new ArrayList<>();
        ArrayList<String> listaPassword = new ArrayList<>();

        gestionale.getAmministratori(listaLogin, listaPassword);

        for (int i = 0; i<listaLogin.size(); i++){
            listaAmministratori.add(new Amministratore(
                    listaLogin.get(i),
                    listaPassword.get(i)
            ));
        }
    }

    public List<Carriera> getCarriereDatabase(){


        GestionaleDAO gestionale = new ImplementazioneGestionaleDAO();

        ArrayList<String> listaSquadre = new ArrayList<>();
        ArrayList<String> listaTrofeiIndividuali = new ArrayList<>();
        ArrayList<Date> listaDateInizio = new ArrayList<>();
        ArrayList<Date> listaDateFine = new ArrayList<>();
        ArrayList<Integer> listaNumPartite = new ArrayList<>();
        ArrayList<Integer> listaNumGolSegnati = new ArrayList<>();
        ArrayList<Integer> listaNumGolSubiti = new ArrayList<>();
        ArrayList<String> listaCf = new ArrayList<>();

        gestionale.getCarriere();

        if (listaCf.size() != listaSquadre.size()) {
            // Qualcosa è andato storto, gestione errore
            return new ArrayList<>(); // Restituisce una lista vuota o fai altro
        }


        for (int i = 0; i < listaCf.size(); i++){
            Carriera carriera = new Carriera(
                    listaSquadre.get(i),
                    listaTrofeiIndividuali.get(i),
                    listaDateInizio.get(i),
                    listaDateFine.get(i),
                    listaNumPartite.get(i),
                    listaNumGolSegnati.get(i),
                    listaNumGolSubiti.get(i),
                    listaCf.get(i));
            listaCarriere.add(carriera);
        }
        return listaCarriere;
    }

    private void getSquadreDatabase(){
        GestionaleDAO gestionale = new ImplementazioneGestionaleDAO();

        ArrayList<String> listaNomi = new ArrayList<>();
        ArrayList<String> listaNazionalita = new ArrayList<>();
        ArrayList<String> listaTrofeiSquadra = new ArrayList<>();

        gestionale.getSquadre(listaNomi,
                listaNazionalita,
                listaTrofeiSquadra
        );

        for (int i = 0; i<listaNomi.size(); i++){
            listaSquadre.add(new Squadra(
                    listaNomi.get(i),
                    listaNazionalita.get(i),
                    listaTrofeiSquadra.get(i)
            ));
        }
    }

    //FUNZIONI PER LA GUI DEI GIOCATORI
    public ArrayList<String> getListaNomi(){
        ArrayList<String> listaNomi = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaNomi.add(g.getNome());
        return listaNomi;
    }

    public ArrayList<String> getListaCognommi(){
        ArrayList<String> listaCognomi = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaCognomi.add(g.getCognome());
        return listaCognomi;
    }

    public ArrayList<String> getListaCf(){
        ArrayList<String> listaCf = new ArrayList<>();
        List<Giocatore> giocDB = getGiocatoriDatabase();


        for (Giocatore g : getGiocatoriDatabase()) {
            listaCf.add(g.getCf());
        }
        return listaCf;
    }

    public ArrayList<Date> getListaDateNascita(){
        ArrayList<Date> listaDateNascita = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaDateNascita.add(g.getDataNascita());
        return listaDateNascita;
    }

    public ArrayList<String> getPiedi(){
        ArrayList<String> listaPiedi = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaPiedi.add(g.getPiede());
        return listaPiedi;
    }

    public ArrayList<String> getListaRuoli(){
        ArrayList<String> listaRuoli = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaRuoli.add(g.getRuolo());
        return listaRuoli;
    }

    public ArrayList<String> getListaFeature(){
        ArrayList<String> listaFeature = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaFeature.add(g.getFeature());
        return listaFeature;
    }

    public ArrayList<Date> getListaDateRitiro(){
        ArrayList<Date> listaDateRitiro = new ArrayList<>();

        for (Giocatore g : listaGiocatori)
            listaDateRitiro.add(g.getDataRitiro());
        return listaDateRitiro;
    }

    public boolean aggiungiGiocatore(String nome, String cognome, Date dataNascita , Date dataRitiro, String piede, String ruolo, String feature, String cf, String nomeSquadra, Date dataInizio) throws SQLException{
        boolean flag = false;
        GiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        flag = giocatoreDAO.nuovoGiocatore(nome,cognome,dataNascita, dataRitiro, piede, ruolo, feature, cf, nomeSquadra, dataInizio);


        if (flag != false)
            return true;
        return false;
    }

    public boolean eliminaGiocatore(String cf) throws SQLException{

        boolean flag = false;

        GiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        flag = giocatoreDAO.eliminaGiocatore(cf);

        if(flag == true)
            return true;

        return false;
    }


    //FUNZIONI PER LA GUI DEGLI AMMINISTRATORI
    public ArrayList<String> getListaPassword(){
        ArrayList<String> listaPassword = new ArrayList<>();

        for (Amministratore a : listaAmministratori)
            listaPassword.add(a.getPassword());
        return listaPassword;
    }

    public ArrayList<String> getListaLogin(){
        ArrayList<String> listaLogin = new ArrayList<>();

        for (Amministratore a : listaAmministratori)
            listaLogin.add(a.getLogin());
        return listaLogin;
    }

    //FUNZIONE DI LOGIN
    public boolean loginAmm(String username, String password) throws SQLException {
        try {
            boolean flag = false;

            // Tentativo di accesso con le credenziali
            AmministratoreDAO amministratoreDAO = new ImplementazioneAmministratoreDAO();
            flag =  amministratoreDAO.accessoAmministratore(username, password);


            // Se l'amministratore è trovato, significa che il login è riuscito
            return flag != false;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    //FUNZIONE PER VISUALIZZARE LA LISTA DEI GIOCATORI IN BASE AI RUOLI
    public ArrayList<Giocatore> giocatoriByRuolo(String ruolo) throws SQLException {
        GiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        ArrayList<Giocatore> listaGiocatoriPerRuolo = new ArrayList<>();

        listaGiocatoriPerRuolo = giocatoreDAO.giocatoriByRuolo(ruolo);

        return listaGiocatoriPerRuolo;
    }

    //FUNZIONE PER VISUALIZZARE LA LISTA DEI GIOCATORI PER PIEDE
   public ArrayList<Giocatore> giocatoriByPiede(String piede) throws SQLException{
        GiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        ArrayList<Giocatore> listaGiocatoriPerPiede = new ArrayList<>();

        listaGiocatoriPerPiede =  giocatoreDAO.giocatoriByPiede(piede);

        return listaGiocatoriPerPiede;
    }

    public Giocatore mostraDatiGiocatore(String cf){
        GiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        Giocatore giocatore = new Giocatore();

        giocatore = giocatoreDAO.mostraGiocatore(cf);

        return giocatore;
    }

    //FUNZIONE PER VISUALIZZARE STORICO GIOCATORI
    public List<Giocatorestorico> storicoGiocatori(String cf) {
        GiocatorestoricoDAO giocatorestoricoDAO = new ImplementazioneGiocatoreStoricoDAO();
        List<Giocatorestorico> storico = new ArrayList<>();

        storico = giocatorestoricoDAO.visualizzaStorico(cf);

        return storico;
    }

    //FUNZIONI PER LA GUI DELLE CARRIERE
    public ArrayList<String> getListaSquadre(){
        ArrayList<String> listaSquadre = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaSquadre.add(c.getSquadra());
        return listaSquadre;
    }

    public ArrayList<String> getListaTrofeiIndividuali(){
        ArrayList<String> listaTrofeiIndividuali = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaTrofeiIndividuali.add(c.getTrofeoIndividuale());
        return listaTrofeiIndividuali;
    }

    public ArrayList<Date> getListadateinizio(){
        ArrayList<Date> listaDateInizio = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaDateInizio.add(c.getDataInizio());
        return listaDateInizio;
    }

    public ArrayList<Date> getListaDateFine(){
        ArrayList<Date> listaDateRitiro = new ArrayList<>();

        for (Carriera c :listaCarriere)
            listaDateRitiro.add(c.getDataFine());
        return listaDateRitiro;
    }

    public ArrayList<Integer> getListaNumPartite(){
        ArrayList<Integer> listaNumPartite = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaNumPartite.add(c.getNumPartite());
        return listaNumPartite;
    }

    public ArrayList<Integer> getListaNumGolSegnati(){
        ArrayList<Integer> listaNumGolSegnati = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaNumGolSegnati.add(c.getNumGolSegnati());
        return listaNumGolSegnati;
    }

    public ArrayList<Integer> getListaNumGolSubiti(){
        ArrayList<Integer> listaNumGolSubiti = new ArrayList<>();

        for (Carriera c : listaCarriere)
            listaNumGolSubiti.add(c.getNumGolSubiti());
        return listaNumGolSubiti;
    }

    public ArrayList<String> getListaCfCarriera(){
        ArrayList<String> listaCf = new ArrayList<>();

        for (Carriera g : listaCarriere)
            listaCf.add(g.getCf());
        return listaCf;
    }

    //FUNZIONE PER VISUALIZZARE LA CARRIERA DEI GIOCATORI
    ArrayList<String> carrieraGiocatore(String cf) throws SQLException{
        CarrieraDAO carrieraDAO = new ImplementazioneCarrieraDAO();

        ArrayList<String> listaCarrieraGiocatore = new ArrayList<>();

        listaCarrieraGiocatore = carrieraDAO.carrieraGiocatore(cf);

        getCarriereDatabase();
        return listaCarrieraGiocatore;
    }

    //FUNZIONI PER LA GUI DELLE SQUADRE
    public ArrayList<String> getListaNomiSquadre(){
        ArrayList<String> listaNomi = new ArrayList<>();

        for (Squadra s : listaSquadre)
            listaNomi.add(s.getNome());
        return listaNomi;
    }

    public ArrayList<String> getListaNazionalita(){
        ArrayList<String> listaNazionalita = new ArrayList<>();

        for (Squadra s : listaSquadre)
            listaNazionalita.add(s.getNazionalita());
        return listaNazionalita;
    }

    public ArrayList<String> getListaTrofeiSquadra(){
        ArrayList<String> listaTrofei = new ArrayList<>();

        for (Squadra s : listaSquadre)
            listaTrofei.add(s.getTrofeoSquadra());
        return listaTrofei;
    }

    public List<String> listaPartecipanti (String nomeSquadrda){
        SquadraDAO squadraDAO = new ImplementazioneSquadraDAO();
        List<String> listaPart = new ArrayList<>();

        listaPart = squadraDAO.listaPartecipanti(nomeSquadrda);

        return listaPart;
    }

    //FUNZIONE PER AGGIUNGERE TROFEO DI SQUADRA
    public  boolean aggiungiTrofeoSquadra(String nomeSquadra, String trofeoSquadra) throws SQLException{
        SquadraDAO squadraDAO = new ImplementazioneSquadraDAO();
        boolean flag;
        try {
            flag = squadraDAO.aggiungiTrofeoSquadra(nomeSquadra, trofeoSquadra);
            return flag != false;
        }catch (SQLException e){
            e.printStackTrace();
            return false;
        }
    }
}
