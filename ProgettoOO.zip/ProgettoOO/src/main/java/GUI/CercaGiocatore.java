package GUI;

import Controller.Controller;
import DAO.GestionaleDAO;
import ImplementazionePostgresDAO.ImplementazioneGestionaleDAO;
import ImplementazionePostgresDAO.ImplementazioneGiocatoreDAO;
import Model.Giocatore;
import Model.Giocatorestorico;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CercaGiocatore {
    private JLabel labelCerca;
    private JPanel contentPane;
    private JList<String> storicoList;
    private JLabel labelFiltri;
    private JPanel panelFiltri;

    private JPanel dettagliPanel;
    private JLabel labelRuoli;
    private JLabel labelPiede;
    private JRadioButton attaccanteRadioButton;
    private JRadioButton portiereRadioButton;
    private JRadioButton difensoreRadioButton;
    private JRadioButton centrocampistaRadioButton;
    private JRadioButton destroRadioButton;
    private JRadioButton sinistroRadioButton;
    private JButton homeButton;
    private JTable gtable;
    private JScrollPane TabScroll;

    public CercaGiocatore(@NotNull Controller controller, JFrame frame) {
        GestionaleDAO gestionale = new ImplementazioneGestionaleDAO();
        ImplementazioneGiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        frame = new JFrame("Rierca giocatori");
        frame.setContentPane(contentPane);
        frame.setSize(new Dimension(1050, 500));
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        DefaultListModel<String> listModel;
        listModel = new DefaultListModel<>();
        storicoList = new JList<>(listModel);
        storicoList.setFont(new Font("Arial", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(storicoList);
        scrollPane.setPreferredSize(new Dimension(300, 200));

        dettagliPanel.setLayout(new BorderLayout());
        dettagliPanel.add(scrollPane, BorderLayout.CENTER);

        List<Giocatore> listaGiocatori = controller.getGiocatoriDatabase();

        //Popolo tabella giocatori
        String[] colonne = {"Nome", "Cognome", "Data di nascita", "Data di ritiro", "Piede", "Ruolo", "Feature", "Codice fiscale"};
        ArrayList<String> listaNomi = controller.getListaNomi();
        ArrayList<String> listaCognomi = controller.getListaCognommi();
        ArrayList<Date> listaDataNascita = controller.getListaDateNascita();
        ArrayList<Date> listaDateRitiro = controller.getListaDateRitiro();
        ArrayList<String> listaPiede = controller.getPiedi();
        ArrayList<String> listaRuoli = controller.getListaRuoli();
        ArrayList<String> listaFeature = controller.getListaFeature();
        ArrayList<String> listaCF = controller.getListaCf();

        String[][] righe = new String[listaCF.size()][8];
        for (int i = 0; i < listaCF.size(); i++) {
            righe[i][0] = listaNomi.get(i);
            righe[i][1] = listaCognomi.get(i);
            righe[i][2] = String.valueOf(listaDataNascita.get(i));
            if (listaDateRitiro.get(i) != null) {
                righe[i][3] = String.valueOf(listaDateRitiro.get(i));
            } else {
                righe[i][3] = "";
            }
            righe[i][4] = listaPiede.get(i);
            righe[i][5] = listaRuoli.get(i);
            righe[i][6] = listaFeature.get(i);
            righe[i][7] = listaCF.get(i);
        }

        DefaultTableModel tableModel = new DefaultTableModel(righe, colonne) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        gtable.setFont(new Font("Arial", Font.PLAIN, 14));
        gtable.setModel(tableModel);
        gtable.setRowHeight(30);

        gtable.getTableHeader().setReorderingAllowed(false);
        gtable.getTableHeader().setResizingAllowed(false);

        resizeWidthTable(gtable);

        Font headerFont = new Font("Arial", Font.BOLD, 14);
        gtable.getTableHeader().setFont(headerFont);

        //Imposto il mouse listener che visualizza lo storico dei calciatori
        gtable.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String cfSelezionato = gtable.getValueAt(gtable.getSelectedRow(), 7).toString();
                List<Giocatorestorico> storico = controller.storicoGiocatori(cfSelezionato);

                listModel.clear();

                for (Giocatorestorico gs : storico) {
                    String storicoDetails = "Squadra: " + gs.getNomeSquadra() + "  " +
                            "Data inizio: " + (gs.getDataInizio() != null ? gs.getDataInizio().toString() : "") + "  " +
                            "Data fine: " + (gs.getDataFine() != null ? gs.getDataFine().toString() : "") + "  " +
                            "Partite: " + gs.getNumPartite() + "  " +
                            "Gol segnati: " + gs.getNumGolSegnati() + "  " +
                            "Gol subiti: " + gs.getNumGolSubiti();
                    listModel.addElement(storicoDetails);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });

        TabScroll.setViewportView(gtable);

        JFrame finalFrame = frame;
        homeButton.addActionListener(e -> {
            finalFrame.setVisible(false);
            new HomeOspiteGUI(controller, finalFrame);
        });

        ButtonGroup group = new ButtonGroup();

        group.add(attaccanteRadioButton);
        group.add(portiereRadioButton);
        group.add(difensoreRadioButton);
        group.add(centrocampistaRadioButton);
        group.add(destroRadioButton);
        group.add(sinistroRadioButton);


        ActionListener listener = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ArrayList<Giocatore> listaFiltrata = new ArrayList<>();

                if (attaccanteRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByRuolo("Attaccante");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else if (portiereRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByRuolo("Portiere");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else if (difensoreRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByRuolo("Difensore");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else if (centrocampistaRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByRuolo("Centrocampista");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else if (destroRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByPiede("Destro");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                } else if (sinistroRadioButton.isSelected()) {
                    try {
                        listaFiltrata = controller.giocatoriByPiede("Sinistro");
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }
                }

                if (listaFiltrata.isEmpty()) {
                    listaFiltrata = new ArrayList<>(listaGiocatori);
                }

                aggiornaTabella(listaFiltrata);
            }
        };
        attaccanteRadioButton.addActionListener(listener);
        portiereRadioButton.addActionListener(listener);
        difensoreRadioButton.addActionListener(listener);
        centrocampistaRadioButton.addActionListener(listener);
        destroRadioButton.addActionListener(listener);
        sinistroRadioButton.addActionListener(listener);
    }

    private void aggiornaTabella(ArrayList<Giocatore> listaFiltrata) {
        String[] colonne = {"Nome", "Cognome", "Data di nascita", "Data di ritiro", "Piede", "Ruolo", "Feature", "Codice fiscale"};

        String[][] righe = new String[listaFiltrata.size()][8];
        for (int i = 0; i < listaFiltrata.size(); i++) {
            Giocatore g = listaFiltrata.get(i);
            righe[i][0] = g.getNome();
            righe[i][1] = g.getCognome();
            righe[i][2] = String.valueOf(g.getDataNascita());
            righe[i][3] = String.valueOf(g.getDataRitiro());
            righe[i][4] = g.getPiede();
            righe[i][5] = g.getRuolo();
            righe[i][6] = g.getFeature();
            righe[i][7] = g.getCf();
        }

        DefaultTableModel newTM = new DefaultTableModel(righe, colonne) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        gtable.setModel(newTM);
        resizeWidthTable(gtable);
    }

    private void resizeWidthTable(JTable table) {
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(100);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        table.getColumnModel().getColumn(7).setPreferredWidth(200);

        table.getColumnModel().getColumn(0).setMinWidth(100);
        table.getColumnModel().getColumn(1).setMinWidth(100);
        table.getColumnModel().getColumn(2).setMinWidth(100);
        table.getColumnModel().getColumn(3).setMinWidth(100);
        table.getColumnModel().getColumn(4).setMinWidth(100);
        table.getColumnModel().getColumn(5).setMinWidth(100);
        table.getColumnModel().getColumn(6).setMinWidth(100);
        table.getColumnModel().getColumn(7).setMinWidth(200);

        table.getColumnModel().getColumn(0).setMaxWidth(100);
        table.getColumnModel().getColumn(1).setMaxWidth(100);
        table.getColumnModel().getColumn(2).setMaxWidth(100);
        table.getColumnModel().getColumn(3).setMaxWidth(100);
        table.getColumnModel().getColumn(4).setMaxWidth(100);
        table.getColumnModel().getColumn(5).setMaxWidth(100);
        table.getColumnModel().getColumn(6).setMaxWidth(100);
        table.getColumnModel().getColumn(7).setMaxWidth(200);
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        contentPane = new JPanel();
        contentPane.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(11, 3, new Insets(0, 0, 0, 0), -1, -1));
        labelCerca = new JLabel();
        Font labelCercaFont = this.$$$getFont$$$("Arial Black", -1, 26, labelCerca.getFont());
        if (labelCercaFont != null) labelCerca.setFont(labelCercaFont);
        labelCerca.setText("Ricerca giocatori");
        contentPane.add(labelCerca, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 1, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(panel1, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 10, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        TabScroll = new JScrollPane();
        TabScroll.setAutoscrolls(true);
        Font TabScrollFont = this.$$$getFont$$$("Arial", -1, 14, TabScroll.getFont());
        if (TabScrollFont != null) TabScroll.setFont(TabScrollFont);
        TabScroll.setHorizontalScrollBarPolicy(32);
        panel1.add(TabScroll, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        gtable = new JTable();
        gtable.setFillsViewportHeight(false);
        gtable.setPreferredScrollableViewportSize(new Dimension(870, 900));
        TabScroll.setViewportView(gtable);
        dettagliPanel = new JPanel();
        dettagliPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        panel1.add(dettagliPanel, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        labelFiltri = new JLabel();
        Font labelFiltriFont = this.$$$getFont$$$("Arial Black", -1, 16, labelFiltri.getFont());
        if (labelFiltriFont != null) labelFiltri.setFont(labelFiltriFont);
        labelFiltri.setText("Filtri:");
        contentPane.add(labelFiltri, new com.intellij.uiDesigner.core.GridConstraints(1, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        panelFiltri = new JPanel();
        panelFiltri.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(6, 1, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(panelFiltri, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        labelRuoli = new JLabel();
        Font labelRuoliFont = this.$$$getFont$$$("Arial", -1, 14, labelRuoli.getFont());
        if (labelRuoliFont != null) labelRuoli.setFont(labelRuoliFont);
        labelRuoli.setText("Ruoli:");
        panelFiltri.add(labelRuoli, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        labelPiede = new JLabel();
        Font labelPiedeFont = this.$$$getFont$$$("Arial", -1, 14, labelPiede.getFont());
        if (labelPiedeFont != null) labelPiede.setFont(labelPiedeFont);
        labelPiede.setText("Piede:");
        panelFiltri.add(labelPiede, new com.intellij.uiDesigner.core.GridConstraints(5, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        attaccanteRadioButton = new JRadioButton();
        attaccanteRadioButton.setText("Attaccante");
        panelFiltri.add(attaccanteRadioButton, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        portiereRadioButton = new JRadioButton();
        portiereRadioButton.setText("Portiere");
        panelFiltri.add(portiereRadioButton, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        difensoreRadioButton = new JRadioButton();
        difensoreRadioButton.setText("Difensore");
        panelFiltri.add(difensoreRadioButton, new com.intellij.uiDesigner.core.GridConstraints(3, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        centrocampistaRadioButton = new JRadioButton();
        centrocampistaRadioButton.setText("Centrocampista");
        panelFiltri.add(centrocampistaRadioButton, new com.intellij.uiDesigner.core.GridConstraints(4, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        contentPane.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(10, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        destroRadioButton = new JRadioButton();
        destroRadioButton.setText("Destro");
        contentPane.add(destroRadioButton, new com.intellij.uiDesigner.core.GridConstraints(3, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        sinistroRadioButton = new JRadioButton();
        sinistroRadioButton.setText("Sinistro");
        contentPane.add(sinistroRadioButton, new com.intellij.uiDesigner.core.GridConstraints(4, 1, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        homeButton = new JButton();
        homeButton.setText("Home");
        contentPane.add(homeButton, new com.intellij.uiDesigner.core.GridConstraints(10, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer2 = new com.intellij.uiDesigner.core.Spacer();
        contentPane.add(spacer2, new com.intellij.uiDesigner.core.GridConstraints(9, 2, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_VERTICAL, 1, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        labelCerca.setLabelFor(TabScroll);
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return contentPane;
    }
}
