package GUI;

import Controller.Controller;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Locale;

public class AmministratoreGUI {
    private JPanel contentPane;
    private JButton aggiungiGiocatoreButton;
    private JScrollPane ScrollPaneList;
    private JPanel buttonPanel;
    private JTable gtable;
    private JButton indietroButton;
    private JButton inserisciTrofeoDiSquadraButton;

    private JButton modificaButton;
    private JButton eliminaButton;

    public AmministratoreGUI(@NotNull Controller controller, JFrame frameChiamante) {
        frameChiamante = new JFrame("Amministratore");
        frameChiamante.setContentPane(contentPane);
        frameChiamante.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frameChiamante.setResizable(false);
        frameChiamante.setSize(new Dimension(900, 600));
        frameChiamante.setLocationRelativeTo(null);
        frameChiamante.setVisible(true);

        modificaButton = new JButton("Modifica giocatore");
        eliminaButton = new JButton("Elimina giocatore");

        buttonPanel.setLayout(new GridLayout(4, 1, 10, 10));

        JFrame finalFrame = frameChiamante;
        aggiungiGiocatoreButton.addActionListener(e -> {
            finalFrame.setVisible(false);
            new AddGiocatoreGUI(controller, finalFrame);
            aggiornaTabella(controller);
        });

        inserisciTrofeoDiSquadraButton.addActionListener(e -> {
            finalFrame.setVisible(false);
            new AggiungiTrofeoSquadraGUI(controller, finalFrame);
        });

        indietroButton.addActionListener(e -> {
            finalFrame.setVisible(false);
            new Home();
        });

        //Popolo tabella giocatori
        String[] colonne = {"Nome", "Cognome", "Data di nascita", "Data di ritiro", "Piede", "Ruolo", "Feature", "Codice fiscale"};
        ArrayList<String> listaNomi = controller.getListaNomi();
        ArrayList<String> listaCognomi = controller.getListaCognommi();
        ArrayList<Date> listaDataNascita = controller.getListaDateNascita();
        ArrayList<Date> listaDateRitiro = controller.getListaDateRitiro();
        ArrayList<String> listaPiede = controller.getPiedi();
        ArrayList<String> listaRuoli = controller.getListaRuoli();
        ArrayList<String> listaFeature = controller.getListaFeature();
        ArrayList<String> listaCF = controller.getListaCf();

        String[][] righe = new String[listaCF.size()][8];
        for (int i = 0; i < listaCF.size(); i++) {
            righe[i][0] = listaNomi.get(i);
            righe[i][1] = listaCognomi.get(i);
            righe[i][2] = String.valueOf(listaDataNascita.get(i));
            if (listaDateRitiro.get(i) != null) {
                righe[i][3] = String.valueOf(listaDateRitiro.get(i));
            } else {
                righe[i][3] = "";
            }
            righe[i][4] = listaPiede.get(i);
            righe[i][5] = listaRuoli.get(i);
            righe[i][6] = listaFeature.get(i);
            righe[i][7] = listaCF.get(i);
        }

        DefaultTableModel tableModel = new DefaultTableModel(righe, colonne) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        gtable.setFont(new Font("Arial", Font.PLAIN, 14));
        gtable.setModel(tableModel);
        gtable.setRowHeight(30);

        gtable.getTableHeader().setReorderingAllowed(false);
        gtable.getTableHeader().setResizingAllowed(false);

        resizeWidthTable(gtable);

        Font headerFont = new Font("Arial", Font.BOLD, 14);
        gtable.getTableHeader().setFont(headerFont);


        gtable.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String cfSelezionato = gtable.getValueAt(gtable.getSelectedRow(), 7).toString();


                //rimuovo i bottoni se già ci sono
                buttonPanel.remove(modificaButton);
                buttonPanel.remove(eliminaButton);

                //aggiungo i bottoni
                buttonPanel.add(modificaButton);
                buttonPanel.add(eliminaButton);

                buttonPanel.revalidate();
                buttonPanel.repaint();


                modificaButton.addActionListener(e1 -> {
                    finalFrame.setVisible(false);
                    new ModificaGiocatoreGUI(controller, finalFrame, cfSelezionato);
                });

                eliminaButton.addActionListener(el -> {
                    boolean flag;
                    int risposta = JOptionPane.showConfirmDialog(null, "Sicuro di voler eliminare questo giocatore?", "Conferma", JOptionPane.YES_NO_OPTION);
                    if (risposta == JOptionPane.YES_OPTION) {

                        try {
                            flag = controller.eliminaGiocatore(cfSelezionato);
                            if (flag) {
                                JOptionPane.showMessageDialog(null, "Giocatore eliminato!");
                            } else {
                                JOptionPane.showMessageDialog(null, "Giocatore non trovato", "Errore eliminazione", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (SQLException ex) {
                            JOptionPane.showMessageDialog(null, "Errore durante l'eliminazione: ");
                        }

                        aggiornaTabella(controller);

                    }
                });
            }

            @Override
            public void mousePressed(MouseEvent e) {

            }

            @Override
            public void mouseReleased(MouseEvent e) {

            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        });
    }

    private void resizeWidthTable(JTable table) {
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(100);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(100);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(100);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        table.getColumnModel().getColumn(7).setPreferredWidth(200);

        table.getColumnModel().getColumn(0).setMinWidth(100);
        table.getColumnModel().getColumn(1).setMinWidth(100);
        table.getColumnModel().getColumn(2).setMinWidth(100);
        table.getColumnModel().getColumn(3).setMinWidth(100);
        table.getColumnModel().getColumn(4).setMinWidth(100);
        table.getColumnModel().getColumn(5).setMinWidth(100);
        table.getColumnModel().getColumn(6).setMinWidth(100);
        table.getColumnModel().getColumn(7).setMinWidth(200);

        table.getColumnModel().getColumn(0).setMaxWidth(100);
        table.getColumnModel().getColumn(1).setMaxWidth(100);
        table.getColumnModel().getColumn(2).setMaxWidth(100);
        table.getColumnModel().getColumn(3).setMaxWidth(100);
        table.getColumnModel().getColumn(4).setMaxWidth(100);
        table.getColumnModel().getColumn(5).setMaxWidth(100);
        table.getColumnModel().getColumn(6).setMaxWidth(100);
        table.getColumnModel().getColumn(7).setMaxWidth(200);
    }

    private void aggiornaTabella(Controller controller) {
        //Popolo tabella giocatori
        String[] colonne = {"Nome", "Cognome", "Data di nascita", "Data di ritiro", "Piede", "Ruolo", "Feature", "Codice fiscale"};
        ArrayList<String> listaNomi = controller.getListaNomi();
        ArrayList<String> listaCognomi = controller.getListaCognommi();
        ArrayList<Date> listaDataNascita = controller.getListaDateNascita();
        ArrayList<Date> listaDateRitiro = controller.getListaDateRitiro();
        ArrayList<String> listaPiede = controller.getPiedi();
        ArrayList<String> listaRuoli = controller.getListaRuoli();
        ArrayList<String> listaFeature = controller.getListaFeature();
        ArrayList<String> listaCF = controller.getListaCf();

        String[][] righe = new String[listaCF.size()][8];
        for (int i = 0; i < listaCF.size(); i++) {
            righe[i][0] = listaNomi.get(i);
            righe[i][1] = listaCognomi.get(i);
            righe[i][2] = String.valueOf(listaDataNascita.get(i));
            righe[i][3] = String.valueOf(listaDateRitiro.get(i));
            righe[i][4] = listaPiede.get(i);
            righe[i][5] = listaRuoli.get(i);
            righe[i][6] = listaFeature.get(i);
            righe[i][7] = listaCF.get(i);
        }

        DefaultTableModel tableModel = new DefaultTableModel(righe, colonne) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        gtable.setModel(tableModel);
        gtable.repaint();
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        contentPane = new JPanel();
        contentPane.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(3, 1, new Insets(0, 0, 0, 0), -1, -1));
        ScrollPaneList = new JScrollPane();
        contentPane.add(ScrollPaneList, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        gtable = new JTable();
        gtable.setPreferredScrollableViewportSize(new Dimension(300, 50));
        ScrollPaneList.setViewportView(gtable);
        buttonPanel = new JPanel();
        buttonPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(2, 1, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(buttonPanel, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, new Dimension(900, 150), null, 0, false));
        inserisciTrofeoDiSquadraButton = new JButton();
        Font inserisciTrofeoDiSquadraButtonFont = this.$$$getFont$$$("Arial", -1, 12, inserisciTrofeoDiSquadraButton.getFont());
        if (inserisciTrofeoDiSquadraButtonFont != null)
            inserisciTrofeoDiSquadraButton.setFont(inserisciTrofeoDiSquadraButtonFont);
        inserisciTrofeoDiSquadraButton.setText("Inserisci trofeo di squadra");
        buttonPanel.add(inserisciTrofeoDiSquadraButton, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        aggiungiGiocatoreButton = new JButton();
        Font aggiungiGiocatoreButtonFont = this.$$$getFont$$$("Arial", -1, 12, aggiungiGiocatoreButton.getFont());
        if (aggiungiGiocatoreButtonFont != null) aggiungiGiocatoreButton.setFont(aggiungiGiocatoreButtonFont);
        aggiungiGiocatoreButton.setText("Aggiungi giocatore");
        buttonPanel.add(aggiungiGiocatoreButton, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_SOUTH, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final JPanel panel1 = new JPanel();
        panel1.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 2, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(panel1, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        indietroButton = new JButton();
        Font indietroButtonFont = this.$$$getFont$$$("Arial", -1, 14, indietroButton.getFont());
        if (indietroButtonFont != null) indietroButton.setFont(indietroButtonFont);
        indietroButton.setText("Indietro");
        panel1.add(indietroButton, new com.intellij.uiDesigner.core.GridConstraints(0, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        final com.intellij.uiDesigner.core.Spacer spacer1 = new com.intellij.uiDesigner.core.Spacer();
        panel1.add(spacer1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_HORIZONTAL, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_WANT_GROW, 1, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return contentPane;
    }
}



