package GUI;

import Controller.Controller;
import ImplementazionePostgresDAO.ImplementazioneGiocatoreDAO;
import Model.Giocatore;
import org.jetbrains.annotations.NotNull;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;
import javax.swing.text.StyleContext;
import java.awt.*;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

public class ModificaGiocatoreGUI extends Component {
    private JTextField CFtextField1;
    private JButton salvaButton;
    private JButton annullaButton;
    private JPanel contentPane;
    private JTextField nometextField1;
    private JTextField cognometextField2;
    private JTextField nascitatextField3;
    private JTextField ritiroTextField;
    private JTextField piedeTextField;
    private JTextField ruoloTextField;
    private JTextField featureTextField;

    private JTextField squadraTextField;

    private JTextField trofeoTextField;
    private JTextField inizioTextField;
    private JTextField fineTextField;
    private JTextField partiteTextField;
    private JTextField segnatiTextField;
    private JTextField subitiTextField;

    private JPanel datiPanel;

    private JFrame frame;

    Controller controller = new Controller();

    SimpleDateFormat formatoData = new SimpleDateFormat("yyyy-MM-dd");

    public ModificaGiocatoreGUI(@NotNull Controller controller, JFrame frameChiamante, String cf) {
        frame = new JFrame("Modifica giocatore");
        frame.setContentPane(contentPane);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setSize(new Dimension(1000, 600));
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        ImplementazioneGiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();
        Giocatore giocatoreCF = new Giocatore();

        giocatoreCF = controller.mostraDatiGiocatore(cf);

        CFtextField1 = new JTextField(cf);
        CFtextField1.setEditable(false);

        JLabel nomeLabel = new JLabel("Nome:");
        nometextField1 = new JTextField(giocatoreCF.getNome());
        nometextField1.setEditable(false);

        JLabel cognomeLabel = new JLabel("Cognome:");
        cognometextField2 = new JTextField(giocatoreCF.getCognome());
        cognometextField2.setEditable(false);

        JLabel nascitaLabel = new JLabel("Data di nascita:");
        nascitatextField3 = new JTextField(giocatoreCF.getDataNascita().toString());
        nascitatextField3.setEditable(false);

        JLabel ritiroLabel = new JLabel("Data di ritiro:");
        String dataRitiroStr = (giocatoreCF.getDataRitiro() != null) ? giocatoreCF.getDataRitiro().toString() : " ";
        ritiroTextField = new JTextField(dataRitiroStr);


        JLabel piedeLabel = new JLabel("Piede:");
        piedeTextField = new JTextField(giocatoreCF.getPiede());
        piedeTextField.setEditable(false);

        JLabel ruoloLabel = new JLabel("Ruolo:");
        ruoloTextField = new JTextField(giocatoreCF.getRuolo());

        JLabel featureLabel = new JLabel("Feature:");
        featureTextField = new JTextField(giocatoreCF.getFeature());

        JLabel squadraLabel = new JLabel("Squadra:");
        squadraTextField = new JTextField(giocatoreCF.getCarriera().getSquadra());
        squadraTextField.setEditable(true);

        JLabel trofeoLabel = new JLabel("Trofeo:");
        trofeoTextField = new JTextField(giocatoreCF.getCarriera().getTrofeoIndividuale());

        JLabel inizioLabel = new JLabel("Data inizio:");
        inizioTextField = new JTextField(giocatoreCF.getCarriera().getDataInizio().toString());
        inizioTextField.setEditable(false);

        String dataFineStr = (giocatoreCF.getCarriera().getDataFine() != null) ? giocatoreCF.getCarriera().getDataFine().toString() : " ";
        JLabel fineLabel = new JLabel("Data fine:");
        fineTextField = new JTextField(dataFineStr);

        String numPartite = (giocatoreCF.getCarriera().getNumPartite() != null) ? giocatoreCF.getCarriera().getNumPartite().toString() : "0";
        JLabel partiteLabel = new JLabel("Numero di partite giocate:");
        partiteTextField = new JTextField(numPartite);

        String numSegnati = (giocatoreCF.getCarriera().getNumGolSegnati() != null) ? giocatoreCF.getCarriera().getNumGolSegnati().toString() : "0";

        JLabel segnatiLabel = new JLabel("Numero gol segnati: ");
        segnatiTextField = new JTextField(numSegnati);
        if (giocatoreCF.getRuolo().equals("portiere")) {
            segnatiTextField.setEditable(false);
        } else {
            segnatiTextField.setEditable(true);
        }


        String numSubiti = (giocatoreCF.getCarriera().getNumGolSubiti() != null) ? giocatoreCF.getCarriera().getNumGolSubiti().toString() : "0";
        JLabel subitiLabel = new JLabel("Numero gol subiti:");
        subitiTextField = new JTextField(numSubiti);
        if (giocatoreCF.getRuolo().equals("portiere")) {
            subitiTextField.setEditable(true);
        } else {
            subitiTextField.setEditable(false);
        }


        datiPanel.setVisible(true);
        datiPanel.setLayout(new GridLayout(14, 2, 10, 10));
        datiPanel.add(nomeLabel);
        datiPanel.add(nometextField1);
        datiPanel.add(cognomeLabel);
        datiPanel.add(cognometextField2);
        datiPanel.add(nascitaLabel);
        datiPanel.add(nascitatextField3);
        datiPanel.add(ritiroLabel);
        datiPanel.add(ritiroTextField);
        datiPanel.add(piedeLabel);
        datiPanel.add(piedeTextField);
        datiPanel.add(ruoloLabel);
        datiPanel.add(ruoloTextField);
        datiPanel.add(featureLabel);
        datiPanel.add(featureTextField);

        datiPanel.add(squadraLabel);
        datiPanel.add(squadraTextField);
        datiPanel.add(trofeoLabel);
        datiPanel.add(trofeoTextField);
        datiPanel.add(inizioLabel);
        datiPanel.add(inizioTextField);
        datiPanel.add(fineLabel);
        datiPanel.add(fineTextField);
        datiPanel.add(partiteLabel);
        datiPanel.add(partiteTextField);
        datiPanel.add(segnatiLabel);
        datiPanel.add(segnatiTextField);
        datiPanel.add(subitiLabel);
        datiPanel.add(subitiTextField);


        datiPanel.revalidate();
        datiPanel.repaint();

        annullaButton.addActionListener(e -> {
            frame.setVisible(false);
            new AmministratoreGUI(controller, frameChiamante);
        });

        salvaButton.addActionListener(e -> {

            try {
                if (onSalva()) {
                    JOptionPane.showMessageDialog(frame, "Dati modificati correttamente!");
                }
            } catch (SQLException ex) {
                throw new RuntimeException(ex);
            } catch (ParseException ex) {
                throw new RuntimeException(ex);
            }

            frame.repaint();
        });
    }

    public boolean onSalva() throws SQLException, ParseException {
        String cf = CFtextField1.getText();
        cf = cf.trim();

        String dataInizio = inizioTextField.getText().trim();
        Date datainizio = new Date(formatoData.parse(dataInizio).getTime());

        ImplementazioneGiocatoreDAO giocatoreDAO = new ImplementazioneGiocatoreDAO();

        String dataRitiro = ritiroTextField.getText().trim();
        Date nuovaDataRitiro = null;

        String regex = "^(\\d{4})-(\\d{2})-(\\d{2})$";
        if (!dataRitiro.isEmpty()) {
            if (!dataRitiro.matches(regex)) {
                JOptionPane.showMessageDialog(this, "Formato data di ritiro non valido, inserire formato corretto: yyyy-MM-dd", "Errore", JOptionPane.ERROR_MESSAGE);
                return false;
            } else {
                nuovaDataRitiro = new Date(formatoData.parse(dataRitiro).getTime());
                if (datainizio.after(nuovaDataRitiro)) {
                    JOptionPane.showMessageDialog(this, "La data di fine deve essere superiore alla data di inizio", "Errore", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
        }

        String nuovaFeature = featureTextField.getText();
        if (nuovaFeature.isEmpty()) {
            nuovaFeature = null;
        }

        String nuovoTrofeo = trofeoTextField.getText();
        if (nuovoTrofeo.isEmpty()) {
            nuovoTrofeo = null;
        }

        String dataFine = fineTextField.getText().trim();
        Date nuovaDataFine = null;
        if (!dataFine.isEmpty()) {
            if (!dataFine.matches(regex)) {
                JOptionPane.showMessageDialog(this, "Formato data di fine non valido, inserire formato corretto: yyyy-MM-dd", "Errore", JOptionPane.ERROR_MESSAGE);
                return false;
            } else {
                nuovaDataFine = new Date(formatoData.parse(dataFine).getTime());
                if (datainizio.after(nuovaDataFine)) {
                    JOptionPane.showMessageDialog(this, "La data di fine deve essere superiore alla data di inizio", "Errore", JOptionPane.ERROR_MESSAGE);
                    return false;
                }
            }
        }

        String partite = partiteTextField.getText();
        Integer nuovoNumPartite = null;
        if (!partite.isEmpty()) {
            try {
                nuovoNumPartite = Integer.parseInt(partite);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Inserisci un numero valido per le partite.", "Errore", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }


        String segnati = segnatiTextField.getText();
        Integer nuovoNumSegnati = null;
        if (!segnati.isEmpty()) {
            try {
                nuovoNumSegnati = Integer.parseInt(segnati);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Inserisci un numero valido per i gol segnati.", "Errore", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        String subiti = subitiTextField.getText();
        Integer nuovoNumSubiti = null;
        if (!subiti.isEmpty()) {
            try {
                nuovoNumSubiti = Integer.parseInt(subiti);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Inserisci un numero valido per i gol subiti.", "Errore", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        String nuovoruolo = ruoloTextField.getText();

        String nuovasquadra = squadraTextField.getText();

        boolean flag = false;

        flag = giocatoreDAO.modificaGiocatore(cf, nuovaDataRitiro, nuovaFeature, nuovoTrofeo, nuovaDataFine, nuovoNumPartite, nuovoNumSegnati, nuovoNumSubiti, nuovoruolo, nuovasquadra);

        if (flag) {
            return true;
        } else {
            return false;
        }

    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        contentPane = new JPanel();
        contentPane.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(3, 2, new Insets(0, 0, 0, 0), -1, -1));
        final JLabel label1 = new JLabel();
        Font label1Font = this.$$$getFont$$$("Arial Black", -1, 24, label1.getFont());
        if (label1Font != null) label1.setFont(label1Font);
        label1.setText("Modifica dati giocatore");
        contentPane.add(label1, new com.intellij.uiDesigner.core.GridConstraints(0, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        datiPanel = new JPanel();
        datiPanel.setLayout(new com.intellij.uiDesigner.core.GridLayoutManager(1, 1, new Insets(0, 0, 0, 0), -1, -1));
        contentPane.add(datiPanel, new com.intellij.uiDesigner.core.GridConstraints(1, 0, 1, 2, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_CENTER, com.intellij.uiDesigner.core.GridConstraints.FILL_BOTH, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, null, null, null, 0, false));
        annullaButton = new JButton();
        annullaButton.setText("Indietro");
        contentPane.add(annullaButton, new com.intellij.uiDesigner.core.GridConstraints(2, 0, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_EAST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
        salvaButton = new JButton();
        salvaButton.setText("Salva");
        contentPane.add(salvaButton, new com.intellij.uiDesigner.core.GridConstraints(2, 1, 1, 1, com.intellij.uiDesigner.core.GridConstraints.ANCHOR_WEST, com.intellij.uiDesigner.core.GridConstraints.FILL_NONE, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_SHRINK | com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_CAN_GROW, com.intellij.uiDesigner.core.GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    private Font $$$getFont$$$(String fontName, int style, int size, Font currentFont) {
        if (currentFont == null) return null;
        String resultName;
        if (fontName == null) {
            resultName = currentFont.getName();
        } else {
            Font testFont = new Font(fontName, Font.PLAIN, 10);
            if (testFont.canDisplay('a') && testFont.canDisplay('1')) {
                resultName = fontName;
            } else {
                resultName = currentFont.getName();
            }
        }
        Font font = new Font(resultName, style >= 0 ? style : currentFont.getStyle(), size >= 0 ? size : currentFont.getSize());
        boolean isMac = System.getProperty("os.name", "").toLowerCase(Locale.ENGLISH).startsWith("mac");
        Font fontWithFallback = isMac ? new Font(font.getFamily(), font.getStyle(), font.getSize()) : new StyleContext().getFont(font.getFamily(), font.getStyle(), font.getSize());
        return fontWithFallback instanceof FontUIResource ? fontWithFallback : new FontUIResource(fontWithFallback);
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return contentPane;
    }
}
