package Model;

import java.sql.Date;

public class Giocatore {
    private String nome;
    private String cognome;
    private String cf;
    private Date dataNascita;
    private String piede;
    private String ruolo;
    private String feature;
    private Date dataRitiro;

    private Squadra squadra;

    private Carriera carriera;

    private Amministratore amministratore;

    public Giocatore(String nome, String cogonme, Date datanascita, Date dataritiro, String piede, String ruolo, String feature, String cf) {
        this.nome = nome;
        this.cognome = cogonme;
        this.dataNascita = datanascita;
        this.dataRitiro = dataritiro;
        this.piede = piede;
        this.ruolo = ruolo;
        this.feature = feature;
        this.cf = cf;
        this.carriera = carriera;
    }

    public Giocatore(){}

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder();

        sb.append(nome).append(" ").append(cognome).append(" ")
                .append(cf).append(" ").append(dataNascita)
                .append(" ").append(piede).append(" ")
                .append(ruolo).append(" ")
                .append(feature != null ? feature : "").append(" ")
                .append(dataRitiro != null ? dataRitiro.toString() : "").append(" ").append(carriera);
        return sb.toString();
    }

    public String getNome() {
        return nome;
    }

    public String getCognome() {
        return cognome;
    }

    public String getCf() {
        return cf;
    }

    public Date getDataNascita() {
        return dataNascita;
    }

    public String getPiede() {
        return piede;
    }

    public String getRuolo() {
        return ruolo;
    }

    public String getFeature() {
        return feature;
    }

    public Date getDataRitiro() {
        return dataRitiro;
    }


    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public void setDataNascita(Date dataNascita) {
        this.dataNascita = dataNascita;
    }

    public void setPiede(String piede) {
        this.piede = piede;
    }

    public void setRuolo(String ruolo) {
        this.ruolo = ruolo;
    }

    public void setFeature(String feature) {
        this.feature = feature;
    }

    public void setDataRitiro(Date dataRitiro) {
        this.dataRitiro = dataRitiro;
    }

    public Squadra getSquadra() {
        return squadra;
    }

    public void setSquadra(Squadra squadra) {
        this.squadra = squadra;
    }

    public Carriera getCarriera() {
        return carriera;
    }

    public void setCarriera(Carriera carriera) {
        this.carriera = carriera;
    }

    public Amministratore getAmministratore() {
        return amministratore;
    }

    public void setAmministratore(Amministratore amministratore) {
        this.amministratore = amministratore;
    }
}
