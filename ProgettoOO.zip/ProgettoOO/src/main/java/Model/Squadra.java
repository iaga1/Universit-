package Model;

import java.util.ArrayList;

public class Squadra {
    private String nome;
    private String nazionalita;
    private String trofeoSquadra;
    private Carriera carriera;
    private ArrayList<Giocatore> listaGiocatori = new ArrayList<>();

    public Squadra(String nome, String nazionalita, String trofeoSquadra) {
        this.nome = nome;
        this.nazionalita = nazionalita;
        this.trofeoSquadra = trofeoSquadra;
    }

    public String getNome() {
        return nome;
    }

    public String getNazionalita() {
        return nazionalita;
    }

    public String getTrofeoSquadra() {
        return trofeoSquadra;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setNazionalita(String nazionalita) {
        this.nazionalita = nazionalita;
    }

    public void setTrofeoSquadra(String trofeoSquadra) {
        this.trofeoSquadra = trofeoSquadra;
    }

    public ArrayList<Giocatore> getListaGiocatori() {
        return listaGiocatori;
    }

    public void setListaGiocatori(ArrayList<Giocatore> listaGiocatori) {
        this.listaGiocatori = listaGiocatori;
    }

    public Carriera getCarriera() {
        return carriera;
    }

    public void setCarriera(Carriera carriera) {
        this.carriera = carriera;
    }
}
