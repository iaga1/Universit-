package Model;

import java.sql.Date;

public class Carriera {
    private String squadra;
    private String trofeoIndividuale;
    private Date dataInizio;
    private Date dataFine;
    private Integer numPartite;
    private Integer numGolSegnati;
    private Integer numGolSubiti;
    private String cf;

    private Giocatore giocatore;

    public Carriera(String squadra, String trofeoIndividuale, Date dataInizio, Date dataFine, Integer numPartite, Integer numGolSegnati, Integer numGolSubiti, String cf) {
        this.squadra = squadra;
        this.trofeoIndividuale = trofeoIndividuale;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.numPartite = numPartite;
        this.numGolSegnati = numGolSegnati;
        this.numGolSubiti = numGolSubiti;
        this.cf = cf;
    }

    public Carriera(){}

    @Override
    public String toString() {
        return "Carriera{" +
                "squadra='" + squadra + '\'' +
                ", trofeoIndividuale='" + trofeoIndividuale + '\'' +
                ", dataInizio=" + dataInizio +
                ", dataFine=" + dataFine +
                ", numPartite=" + numPartite +
                ", numGolSegnati=" + numGolSegnati +
                ", numGolSubiti=" + numGolSubiti +
                ", cf='" + cf + '\'' +
                ", giocatore=" + giocatore +
                '}';
    }

    public String getSquadra() {
        return squadra;
    }

    public String getTrofeoIndividuale() {
        return trofeoIndividuale;
    }

    public Date getDataInizio() {
        return dataInizio;
    }

    public Date getDataFine() {
        return dataFine;
    }

    public Integer getNumPartite() {
        return numPartite;
    }

    public Integer getNumGolSegnati() {
        return numGolSegnati;
    }

    public Integer getNumGolSubiti() {
        return numGolSubiti;
    }

    public void setSquadra(String squadra) {
        this.squadra = squadra;
    }

    public void setTrofeoIndividuale(String trofeoIndividuale) {
        this.trofeoIndividuale = trofeoIndividuale;
    }

    public void setDataInizio(Date dataInizio) {
        this.dataInizio = dataInizio;
    }

    public void setDataFine(Date dataFine) {
        this.dataFine = dataFine;
    }

    public void setNumPartite(Integer numPartite) {
        this.numPartite = numPartite;
    }

    public void setNumGolSegnati(Integer numGolSegnati) {
        this.numGolSegnati = numGolSegnati;
    }

    public void setNumGolSubiti(Integer numGolSubiti) {
        this.numGolSubiti = numGolSubiti;
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public Giocatore getGiocatore() {
        return giocatore;
    }

    public void setGiocatore(Giocatore giocatore) {
        this.giocatore = giocatore;
    }
}
