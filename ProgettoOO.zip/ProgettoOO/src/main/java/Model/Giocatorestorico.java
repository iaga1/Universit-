package Model;

import java.util.Date;

public class Giocatorestorico {
    private String cf;
    private String nomeSquadra;
    private Date dataInizio;
    private Date dataFine;
    private Integer numPartite;
    private Integer numGolSegnati;
    private Integer numGolSubiti;

    public Giocatorestorico(String cf, String nomeSquadra, Date dataInizio, Date dataFine, Integer numPartite, Integer numGolSegnati, Integer numGolSubiti) {
        this.cf = cf;
        this.nomeSquadra = nomeSquadra;
        this.dataInizio = dataInizio;
        this.dataFine = dataFine;
        this.numPartite = numPartite;
        this.numGolSegnati = numGolSegnati;
        this.numGolSubiti = numGolSubiti;
    }

    public String getCf() {
        return cf;
    }

    public void setCf(String cf) {
        this.cf = cf;
    }

    public String getNomeSquadra() {
        return nomeSquadra;
    }

    public void setNomeSquadra(String nomeSquadra) {
        this.nomeSquadra = nomeSquadra;
    }

    public Date getDataInizio() {
        return dataInizio;
    }

    public void setDataInizio(Date dataInizio) {
        this.dataInizio = dataInizio;
    }

    public Date getDataFine() {
        return dataFine;
    }

    public void setDataFine(Date dataFine) {
        this.dataFine = dataFine;
    }

    public Integer getNumPartite() {
        return numPartite;
    }

    public void setNumPartite(Integer numPartite) {
        this.numPartite = numPartite;
    }

    public Integer getNumGolSegnati() {
        return numGolSegnati;
    }

    public void setNumGolSegnati(Integer numGolSegnati) {
        this.numGolSegnati = numGolSegnati;
    }

    public Integer getNumGolSubiti() {
        return numGolSubiti;
    }

    public void setNumGolSubiti(Integer numGolSubiti) {
        this.numGolSubiti = numGolSubiti;
    }

    @Override
    public String toString() {
        return "Giocatorestorico{" +
                "cf='" + cf + '\'' +
                ", nomeSquadra='" + nomeSquadra + '\'' +
                ", dataInizio=" + dataInizio  +
                ", dataFine=" + dataFine+
                ", numPartite=" + numPartite +
                ", numGolSegnati=" + numGolSegnati +
                ", numGolSubiti=" + numGolSubiti +
                '}';
    }
}
