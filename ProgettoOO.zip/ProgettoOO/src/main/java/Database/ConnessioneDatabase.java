package Database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnessioneDatabase {
    private static ConnessioneDatabase instance;
    public Connection connection;

    private ConnessioneDatabase(){
        try {
            String url = "jdbc:postgresql://localhost:5432/ProgettoOO";
            String user = "postgres";
            String password = "0000";
            connection = DriverManager.getConnection(url, user, password);
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("Errore: " + e.getMessage());
        }
    }

    public static ConnessioneDatabase getInstance() throws  SQLException{
        if(instance == null){
            instance = new ConnessioneDatabase();
        } else if (instance.connection.isClosed()) {
            instance.connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/ProgettoOO", "postgres", "0000");
        }
        return instance;
    }

    public Connection getConnection() throws SQLException{
        return connection;
    }

    public void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }

}
