package ImplementazionePostgresDAO;

import DAO.AmministratoreDAO;
import Database.ConnessioneDatabase;

import java.sql.*;
import java.util.ArrayList;

public class ImplementazioneAmministratoreDAO implements AmministratoreDAO {
    private Connection connection;

    public ImplementazioneAmministratoreDAO(){
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        }catch (SQLException e){
            e.printStackTrace();
        }
    }



    @Override
    public boolean accessoAmministratore(String login, String password) throws SQLException{

        try {
            PreparedStatement query;

            query = connection.prepareStatement("SELECT COUNT(*) FROM amministratore WHERE login = ? AND password = ?");

            query.setString(1, login);
            query.setString(2, password);

            ResultSet rs = query.executeQuery();
            if (rs.next()) {
                int count = rs.getInt(1);
                if (count > 0){
                    return true;
                }
            }
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


}
