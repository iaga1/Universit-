package ImplementazionePostgresDAO;

import DAO.GiocatoreDAO;
import Database.ConnessioneDatabase;
import Model.Carriera;
import Model.Giocatore;

import java.sql.*;
import java.util.ArrayList;

public class ImplementazioneGiocatoreDAO implements GiocatoreDAO {
    private Connection connection;

    public ImplementazioneGiocatoreDAO(){
        try {
                connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Errore: " + e.getMessage());
        }
    }

    @Override
    public boolean nuovoGiocatore(String nome, String cognome, Date dataNascita, Date dataRitiro, String piede, String ruolo, String feature, String cf, String nomeSquadra, Date dataInizio) throws SQLException{
        try {
            CallableStatement query;
            query = connection.prepareCall("select add_giocatore(?,?,?,?,?,?,?,?,?,?)");
            query.setString(1, nome);
            query.setString(2, cognome);
            query.setDate(3, dataNascita);
            query.setDate(4, dataRitiro);
            query.setString(5, piede);
            query.setString(6, ruolo);
            query.setString(7, feature);
            query.setString(8, cf);
            query.setString(9, nomeSquadra);
            query.setDate(10, dataInizio);
            query.execute();

            return true;
        }catch (SQLException e){
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }return false;
    }





    @Override
    public boolean eliminaGiocatore(String cf) throws SQLException{

        try {
            if (connection == null || connection.isClosed()){
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement  query;
            query = connection.prepareCall("select elimina_giocatore(?)");
            query.setString(1, cf);

            query.executeQuery();
            return true;
        }catch (SQLException e){
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
            return  false;
        }

    }
    @Override
    public ArrayList<Giocatore> giocatoriByRuolo(String ruolo)  {
        ArrayList<Giocatore> listaGiocatori = new ArrayList<>();

        try {
            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM giocatore WHERE ruolo = ?");
            query.setString(1,ruolo);

            ResultSet rs = query.executeQuery();

            while (rs.next()){
                listaGiocatori.add(new Giocatore(rs.getString("nome"), rs.getString("cognome"), rs.getDate("datanascita"),
                        rs.getDate("dataritiro"), rs.getString("piede"), rs.getString("ruolo"), rs.getString("feature"),
                        rs.getString("cf")));
            }
        }catch (SQLException e){
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }

        return listaGiocatori;
    }

    @Override
    public ArrayList<Giocatore> giocatoriByPiede(String piede) {
        ArrayList<Giocatore> listaGiocatori = new ArrayList<>();

        try {
            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM giocatore WHERE piede = ?");
            query.setString(1,piede);

            ResultSet rs = query.executeQuery();
            while (rs.next())
                listaGiocatori.add(new Giocatore(rs.getString("nome"), rs.getString("cognome"), rs.getDate("datanascita"),
                        rs.getDate("dataritiro"), rs.getString("piede"), rs.getString("ruolo"), rs.getString("feature"),
                        rs.getString("cf")));
        }catch (SQLException e){
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }
        return listaGiocatori;
    }

    @Override
    public Giocatore mostraGiocatore(String cf){
        Giocatore giocatoreCF = null;

        try {
            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareStatement(" SELECT * FROM mostra_giocatore(?)");
            query.setString(1, cf);

            try (ResultSet rs = query.executeQuery();){
                while (rs.next()) {
                    Giocatore giocatore = new Giocatore(
                            rs.getString("nome"),
                            rs.getString("cognome"),
                            rs.getDate("datanascita"),
                            rs.getDate("dataritiro"),
                            rs.getString("piede"),
                            rs.getString("ruolo"),
                            rs.getString("feature"),
                            rs.getString("cf")
                    );
                    Carriera carriera = new Carriera(
                            rs.getString("squadra"),
                            rs.getString("trofeoindividuale"),
                            rs.getDate("datainizio"),
                            rs.getDate("datafine"),
                            rs.getInt("numpartite"),
                            rs.getInt("numgolsegnati"),
                            rs.getInt("numgolsubiti"),
                            rs.getString("carriera_cf")
                    );

                    giocatore.setCarriera(carriera);
                    giocatoreCF = giocatore;
                    }
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return giocatoreCF;
    }

    @Override
    public boolean modificaGiocatore(String cf, Date dataRitiro, String feature, String trofeo, Date dataFine, Integer numPartite, Integer numGolSegnati, Integer numGolsubiti, String ruolo, String squadra){

        try {
            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareStatement("SELECT modifica_giocatore(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            query.setString(1, cf);

            if (dataRitiro != null){
                query.setDate(2, dataRitiro);
            }else {
                query.setNull(2, Types.DATE);
            }

            if (feature != null){
                query.setString(3, feature);
            }else {
                query.setNull(3, Types.VARCHAR);
            }

            if (trofeo != null){
                query.setString(4, trofeo);
            }else {
                query.setNull(4, Types.VARCHAR);
            }

            if (dataFine != null ){
                query.setDate(5, dataFine);
            }else {
                query.setNull(5, Types.DATE);
            }

            if (numPartite != null){
                query.setInt(6, numPartite);
            }else {
                query.setNull(6, Types.INTEGER);
            }

            if (numGolSegnati != null){
                query.setInt(7, numGolSegnati);
            }else {
                query.setNull(7, Types.INTEGER);
            }

            if (numGolsubiti != null){
                query.setInt(8, numGolsubiti);
            }else {
                query.setNull(8, Types.INTEGER);
            }

            if (ruolo != null){
                query.setString(9, ruolo);
            }else {
                query.setNull(9, Types.VARCHAR);
            }

            if (squadra != null){
                query.setString(10, squadra);
            }else {
                query.setNull(10, Types.VARCHAR);
            }



            ResultSet rs = query.executeQuery();

            int rowCount = 0;
            while (rs.next()){
                rowCount++;
            }
            if (rowCount>0){
                return true;
            }
        }catch (SQLException ex){
            ex.printStackTrace();
            ex.getMessage();
        }
        return false;
    }

}

