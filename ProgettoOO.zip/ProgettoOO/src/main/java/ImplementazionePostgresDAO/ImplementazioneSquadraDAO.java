package ImplementazionePostgresDAO;

import DAO.SquadraDAO;
import Database.ConnessioneDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ImplementazioneSquadraDAO implements SquadraDAO {
    Connection connection;

    public ImplementazioneSquadraDAO() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean aggiungiTrofeoSquadra(String nomeSquadra, String trofeo) throws SQLException {

        try {
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareCall("SELECT add_trofeo_squadra(?,?)");
            query.setString(1, nomeSquadra);
            query.setString(2, trofeo);
            query.executeQuery();
            return true;
        } catch (SQLException e) {
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<String> listaPartecipanti(String nomeSquadra) {
        ArrayList<String> listaPartecipanti = new ArrayList<>();
        try {
            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM mostra_partecipanti(?)");

            query.setString(1, nomeSquadra);

            ResultSet rs = query.executeQuery();

            while (rs.next()) {
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");

                listaPartecipanti.add(nome + " " + cognome);
            }
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Errore lettura dati da database");
        }
        return listaPartecipanti;
    }

}



