package ImplementazionePostgresDAO;

import DAO.GestionaleDAO;
import Database.ConnessioneDatabase;
import Model.Carriera;
import Model.Giocatore;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ImplementazioneGestionaleDAO implements GestionaleDAO {
    Connection connection;

    public ImplementazioneGestionaleDAO(){
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        }catch (SQLException e){
            System.out.println("Errore lettura dati da database");
            e.printStackTrace();
        }
    }

    @Override
    public List<Giocatore> getGiocatori(){
        List<Giocatore> listaGiocatori = new ArrayList<>();

        try {
            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM giocatore");
            ResultSet rs = query.executeQuery();

            while (rs.next()){
                String nome = rs.getString("nome");
                String cognome = rs.getString("cognome");
                Date dateNascita = rs.getDate("datanascita");
                Date dateRitiro = rs.getDate("dataritiro");
                String piede = rs.getString("piede");
                String ruolo = rs.getString("ruolo");
                String feature = rs.getString("feature");
                String cf = rs.getString("cf");

                Giocatore giocatore = new Giocatore(nome, cognome, dateNascita, dateRitiro, piede, ruolo, feature, cf);
                listaGiocatori.add(giocatore);
            }
            connection.close();
        }catch (SQLException e){
            System.out.println("Errore lettura dati da database");
            e.printStackTrace();
        }
        return listaGiocatori;
    }

    @Override
    public List<Carriera> getCarriere(){
            List<Carriera> listaCarriera = new ArrayList<>();

        try {

            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }

            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM  carriera");
            ResultSet rs = query.executeQuery();

            while (rs.next()){
                String squadra = rs.getString("squadra");
                String trofeoIndividuale = rs.getString("trofeoindividuale");
                Date dataInizio = rs.getDate("datainizio");
                Date dataFine = rs.getDate("datafine");
                Integer numPartite = rs.getInt("numpartite");
                Integer golSegnati = rs.getInt("numgolsegnati");
                Integer golSubiti = rs.getInt("numgolsubiti");
                String cf = rs.getString("cf");

                Carriera carriera = new Carriera(squadra, trofeoIndividuale, dataInizio, dataFine, numPartite, golSegnati, golSubiti, cf);
                listaCarriera.add(carriera);
            }
            connection.close();
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("Errore lettura dati da database");
            System.out.println("Errore: " + e.getMessage());
        }
        return listaCarriera;
    }

    @Override
    public void getAmministratori(ArrayList<String> listaLogin, ArrayList<String> listaPassword){
        try {
            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM  amministratore");
            ResultSet rs = query.executeQuery();

            while (rs.next()){
                listaLogin.add(rs.getString("login"));
                listaPassword.add(rs.getString("password"));
            }
            connection.close();
        }
        catch (SQLException e){
            e.printStackTrace();
            System.out.println("Errore lettura dati da database");
        }
    }

    @Override
    public void getSquadre(ArrayList<String> listaNomi, ArrayList<String> listaNazionalita, ArrayList<String>  listaTrofeiSquadra){
        try {
            // Verifica se la connessione è chiusa e riapri se necessario
            if (connection == null || connection.isClosed()) {
                connection = ConnessioneDatabase.getInstance().getConnection();
            }
            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM  squadra");
            ResultSet rs = query.executeQuery();

            while (rs.next()){
                listaNomi.add(rs.getString("nome"));
                listaNazionalita.add(rs.getString("nazionalita"));
                listaTrofeiSquadra.add(rs.getString("trofeisquadra"));
            }
            connection.close();
        }
        catch (SQLException e){
            e.printStackTrace();
            System.out.println("Errore lettura dati da database");
        }
    }

}
