package ImplementazionePostgresDAO;

import DAO.GiocatorestoricoDAO;
import Database.ConnessioneDatabase;
import Model.Giocatorestorico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ImplementazioneGiocatoreStoricoDAO implements GiocatorestoricoDAO{

    private Connection connection;

    public ImplementazioneGiocatoreStoricoDAO() {
        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


      @Override
        public List<Giocatorestorico> visualizzaStorico(String cf) {
            List<Giocatorestorico> storico = new ArrayList<>();

            try {
                // Verifica se la connessione è chiusa e riapri se necessario
                if (connection == null || connection.isClosed()) {
                    connection = ConnessioneDatabase.getInstance().getConnection();
                }

                PreparedStatement query;
                query = connection.prepareStatement("SELECT * FROM  storico_giocatore(?)");
                query.setString(1, cf);

                ResultSet rs = query.executeQuery();
                while (rs.next()) {
                    String rscf = rs.getString("cf");
                    String nomesquadra = rs.getString("nomesquadra");
                    Date datainizio = rs.getDate("datainizio");
                    Date datafine = rs.getDate("datafine");
                    int numpartite = rs.getInt("numpartite");
                    int numgolsegnari = rs.getInt("numgolsegnati");
                    int numgolsubiti = rs.getInt("numgolsubiti");

                    storico.add(new Giocatorestorico(rscf, nomesquadra, datainizio, datafine, numpartite, numgolsegnari, numgolsubiti));
                }
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("Errore: " + e.getMessage());
            }
            return storico;
        }

}
