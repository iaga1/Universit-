package ImplementazionePostgresDAO;

import DAO.CarrieraDAO;
import Database.ConnessioneDatabase;

import java.sql.*;
import java.util.ArrayList;

public class ImplementazioneCarrieraDAO implements CarrieraDAO {
    private Connection connection;

    public ImplementazioneCarrieraDAO(){

        try {
            connection = ConnessioneDatabase.getInstance().getConnection();
        }catch (SQLException e){
            e.printStackTrace();
            System.out.println("Errore: " + e.getMessage());
        }
    }
    @Override
    public ArrayList<String> carrieraGiocatore(String cfGiocatore) throws SQLException{
        ArrayList<String> listaCarrieraGiocatore = new ArrayList<>();

        try {
            PreparedStatement query;
            query = connection.prepareStatement("SELECT * FROM carriera WHERE cf = ?");
            query.setString(1, cfGiocatore);

            ResultSet rs = query.executeQuery();

            while (rs.next())
                listaCarrieraGiocatore.add("squadra" + " " + "trofeoindividuale" + " " + "datainizio" + " " + "datafine" + " " + "numpartite" + " " + "numgolsegnati" + " " + "numgolsubiti" + " " + "cf");
        }catch (SQLException e){
            System.out.println("Errore: " + e.getMessage());
            e.printStackTrace();
        }
        return listaCarrieraGiocatore;
    }
}
