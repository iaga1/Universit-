package Main;

import GUI.Home;
import com.formdev.flatlaf.IntelliJTheme;

import java.io.InputStream;

public class Main {
    public static void main(String[] args){

        InputStream themeStream = Main.class.getResourceAsStream("/DarkFlatTheme.theme.json");


        if (themeStream == null) {
            System.out.println("Errore: il file JSON del tema non è stato trovato.");
        } else {            
            IntelliJTheme.setup(themeStream);
        }
        new Home();
    }
}
