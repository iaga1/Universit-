package DAO;

import java.sql.*;
import java.util.ArrayList;

public interface CarrieraDAO {

    ArrayList<String> carrieraGiocatore(String cfGiocatore) throws SQLException;
}
