package DAO;

import Model.Carriera;
import Model.Giocatore;

import java.util.ArrayList;
import java.util.List;

public interface GestionaleDAO {

    List<Giocatore> getGiocatori();

    List<Carriera> getCarriere();

    void getSquadre(
            ArrayList<String> listaNomi,
            ArrayList<String> listaNazionalita,
            ArrayList<String>  listaTrofeiSquadra
    );

    void getAmministratori(
            ArrayList<String> listaLogin,
            ArrayList<String> listaPassword
    );
}
