package DAO;

import Model.Giocatorestorico;

import java.sql.SQLException;
import java.util.List;

public interface SquadraDAO {

    boolean aggiungiTrofeoSquadra(String nomeSquadra, String trofeoSquadra) throws SQLException;

    List<String> listaPartecipanti(String nomeSquadra);
}
