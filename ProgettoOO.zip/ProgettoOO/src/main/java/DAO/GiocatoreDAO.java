package DAO;

import Model.Giocatore;

import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;

public interface GiocatoreDAO {

    boolean nuovoGiocatore(String nome, String cognome, Date dataNascita, Date dataRitiro, String piede, String ruolo, String feature, String cf, String nomeSquadra, Date dataInizio) throws SQLException;

    boolean eliminaGiocatore(String cf) throws SQLException;

    ArrayList<Giocatore> giocatoriByRuolo(String ruolo) ;

    ArrayList<Giocatore> giocatoriByPiede(String piede) ;

    Giocatore mostraGiocatore(String cf);

    boolean modificaGiocatore(String cf, Date dataRitiro, String feature, String trofeo, Date dataFine, Integer numPartite, Integer numGolSegnati, Integer numGolsubiti, String ruolo, String squadra);
}
