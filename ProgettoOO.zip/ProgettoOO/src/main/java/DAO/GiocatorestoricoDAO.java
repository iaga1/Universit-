package DAO;

import Model.Giocatorestorico;

import java.util.List;

public interface GiocatorestoricoDAO {

    List<Giocatorestorico> visualizzaStorico(String cf);
}
