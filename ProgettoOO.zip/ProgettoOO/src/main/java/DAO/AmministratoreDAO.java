package DAO;


import java.sql.SQLException;
import java.util.ArrayList;


public interface AmministratoreDAO {

    boolean accessoAmministratore(String login, String password) throws SQLException;


}
